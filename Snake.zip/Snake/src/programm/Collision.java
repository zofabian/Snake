package programm;

import game.Snake;

public class Collision {
	
	public static boolean selfCollison() {
		for(int i=0;i<Snake.vect.size();i++) {
			if(Snake.head1.getX() == Snake.vect.get(i).getX() && Snake.head1.getY() == Snake.vect.get(i).getY() && Snake.vect.get(i).isWait() == false){
				Snake.points = 0;
				/*endGUI end = new endGUI();*/
				return true;
			}
		}
		return false;
	}
	
	public static boolean wallCollision(){
		if (Snake.head1.getX()<0 || Snake.head1.getX()>15 || Snake.head1.getY()<0 || Snake.head1.getY()>15) {
			Snake.points = 0;
			/*endGUI end = new endGUI();*/
			return true;
			
		}
		return false;
	}
	
	public static void eatApple() {
		if(Snake.head1.getX() == Snake.apple.getX() && Snake.head1.getY() == Snake.apple.getY()) {
			Snake.apple.newApple();
			Snake.addTail();
			Snake.points +=1;

			}
			
		}
	}

