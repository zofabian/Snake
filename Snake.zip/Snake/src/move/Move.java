package move;

import game.Snake;
import programm.Collision;

public class Move extends Thread{
	public boolean moving = true;
	
	public void move() {
		while(moving) {
			try {
				sleep(200);
				Snake.move();
				Snake.waitMove = false;
				Collision.eatApple();
				if(Collision.selfCollison()) {
					Snake.vect.clear();
				}
				
				if(Collision.wallCollision()) {
					Snake.vect.clear();
					Snake.head1.setX(7);
					Snake.head1.setY(7);
				}
			}
			catch(InterruptedException e){
				e.printStackTrace();
			}
				
		}
	}
}
