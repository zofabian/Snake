package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import game.Dir;
import game.Snake;
import programm.Direction;

public class snakeGUI extends JFrame implements ActionListener{
	public static int x=150,y=50;
	private KeyEvent e;
	private ActionEvent k;
	private draw d;
	private Direction dir;
	public JDialog dialog;
	public JLabel label;
	public JTextField text;
	public JButton button;
	public JPanel panel;
	public static String username;

	
	public snakeGUI() {
		super("Snake");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(700, 600);
		this.setResizable(false);
		this.requestFocus();
		d = new draw();
		add(d);
		addKeyListener(new Direction());
		
		init();
		setVisible(true);
	}
	
	public void init() {
		dialog = new JDialog();
		label = new JLabel("Username: ");
		text = new JTextField();
		button = new JButton("Start");
		button.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent k) {
				username = text.getText();
				dialog.dispose();	
			}
		});
		panel = new JPanel(new GridLayout(2, 1));
		
		dialog.setSize(350, 150);
		dialog.setModal(true);
		text.setForeground(Color.BLACK);
		text.setBackground(Color.WHITE);
		text.setSize(100, 50);
		
		panel.add(label);
		panel.add(text);
		panel.add(button);
		
		dialog.add(panel);
		dialog.setVisible(true);
		
	}
	


	public void actionPerformed(ActionEvent k) {
			dialog.dispose();	
	}

	public Object getValue(String arg0) {
		// TODO Auto-generated method stub
		return null;
	}

	public void putValue(String arg0, Object arg1) {
		// TODO Auto-generated method stub
		
	}
}

