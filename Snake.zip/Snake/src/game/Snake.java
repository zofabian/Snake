package game;

import java.awt.Point;
import java.util.Vector;

import gui.snakeGUI;

public class Snake {
	public static Head head1;
	public static Vector<Tail> vect;
	public static boolean waitMove = false;
	public static Apple apple;
	public static int points = 0;
	
	public Snake() {
	head1 = new Head(7,7);
	vect= new Vector<>();
	apple = new Apple();
	}
	
	public static void addTail() {
        if (vect.size() < 1) {
            vect.add(new Tail(head1.getX(), head1.getY()));
        } else {
            vect.add(new Tail(vect.get(vect.size() - 1).x, vect.get(vect.size() - 1).y));
        }
    }

    public static void move() {
        /*Move rest of the tail*/
        if (vect.size() >= 2) {
            for (int i = vect.size() - 1; i >= 1; i--) {
                if (vect.get(i).isWait() == true) {
                    vect.get(i).setWait(false);
                } else {
                    vect.get(i).setX(vect.get(i - 1).getX());
                    vect.get(i).setY(vect.get(i - 1).getY());
                }
            }
        }

        /*Move first part of Tail*/
        if (vect.size() >= 1) {
            if (vect.get(0).isWait() == true) {
                vect.get(0).setWait(false);
            } else {
                vect.get(0).setX(head1.getX());
                vect.get(0).setY(head1.getY());
            }
        }

        /*Move head*/
        switch (head1.getDir()) {
            case RIGHT:
                head1.setX(head1.getX() + 1);
                break;
            case UP:
                head1.setY(head1.getY() - 1);
                break;
            case LEFT:
                head1.setX(head1.getX() - 1);
                break;
            case DOWN:
                head1.setY(head1.getY() + 1);
                break;
        }

    }

    public static Point p(int x, int y) {
        Point p = new Point(0, 0);
        p.x = x * 32 + snakeGUI.x;
        p.y = y * 32 + snakeGUI.y;

        return p;
    }

}