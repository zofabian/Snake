package programm;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import game.Dir;
import game.Snake;

public class Direction implements KeyListener{

	public void keyPressed(KeyEvent e) {
        switch (e.getKeyCode()) {
            case KeyEvent.VK_W:
                if (Snake.head1.getDir() != Dir.DOWN && Snake.waitMove == false) {
                    Snake.head1.setDir(Dir.UP);
                    Snake.waitMove = true;
                }
                break;
            case KeyEvent.VK_A:
                if (Snake.head1.getDir() != Dir.RIGHT && Snake.waitMove == false) {
                    Snake.head1.setDir(Dir.LEFT);
                    Snake.waitMove = true;
                }
                break;
            case KeyEvent.VK_S:
                if (Snake.head1.getDir() != Dir.UP && Snake.waitMove == false) {
                    Snake.head1.setDir(Dir.DOWN);
                    Snake.waitMove = true;
                }
                break;
            case KeyEvent.VK_D:
                if (Snake.head1.getDir() != Dir.LEFT && Snake.waitMove == false) {
                    Snake.head1.setDir(Dir.RIGHT);
                    Snake.waitMove = true;
                }
                break;
        }
    }

	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}
