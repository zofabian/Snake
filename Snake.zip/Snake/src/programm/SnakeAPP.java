package programm;

import game.Snake;
import gui.draw;
import gui.snakeGUI;
import move.Move;

public class SnakeAPP {
	public static void main(String[]args) {
		snakeGUI gui;
		Move m;
		Snake s;
		
		gui = new snakeGUI();
		m = new Move();
		s = new Snake();
		
		m.move();
		s.move();
	
		
		
	}
}
