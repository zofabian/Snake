package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;

import javax.swing.JLabel;

import game.Snake;

public class draw extends JLabel{
	Point point;


	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
	    g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_OFF);
	    
	    /*Hintergrund, Rand*/
	    g.setColor(Color.WHITE);
		g.fillRect(0, 0, snakeGUI.WIDTH, snakeGUI.HEIGHT);
	    
		g.setColor(Color.BLACK);
		g.drawRect(snakeGUI.x,snakeGUI.y,512,512);
		
		/*Head*/
		g.setColor(Color.CYAN);
		point = Snake.p(Snake.head1.getX(), Snake.head1.getY());
		g.fillRect(point.x, point.y, 32, 32);
		
		/*Tail*/
		g.setColor(Color.BLUE);
		for(int i = 0;i<Snake.vect.size();i++) {
			point = Snake.p(Snake.vect.get(i).getX(), Snake.vect.get(i).getY());
			g.fillRect(point.x, point.y, 32, 32);
		}
		
		
		
		/*Apple*/
		g.setColor(Color.RED);
		point = Snake.p(Snake.apple.getX(), Snake.apple.getY());
		g.fillRect(point.x, point.y, 32, 32);
		
		/*Gitter*/
		g.setColor(Color.BLACK);
		for(int i=0;i<16;i++) {
			for(int j=0;j<16;j++) {
				g.drawRect(i*32 + snakeGUI.x , j*32 + snakeGUI.y, 32, 32);
			}
		}
		
		/*Username + Points*/
		g.setFont(new Font("Calibri", 10, 25));
		g.drawString("Points: " + Snake.points, 10, 550);
		g.drawString("Username: ", 10, 30);
		g.drawString(snakeGUI.username, 10, 60);
		
		repaint(); 
	}
}
