package game;

public enum Dir {
	UP,LEFT,RIGHT,DOWN
}
